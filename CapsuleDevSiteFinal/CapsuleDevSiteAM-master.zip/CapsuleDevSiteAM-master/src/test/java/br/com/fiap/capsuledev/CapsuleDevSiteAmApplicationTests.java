package br.com.fiap.capsuledev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapsuleDevSiteAmApplicationTests {

	@Test
	void contextLoads() {
	}

}
